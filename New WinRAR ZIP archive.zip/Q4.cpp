#include <iostream>
using namespace std;

#define MAX 100000

int main() {
    int nums[] = {4, 5, 1, 2, 0, 4};
    int n = 6;

    int hash[MAX] = {0};

    for (int i = 0; i < n; i++)
        hash[nums[i]]++;

    for (int i = 0; i < n; i++) {
        if (hash[nums[i]] == 1) {
            cout << nums[i];
            break;
        }
    }
}
