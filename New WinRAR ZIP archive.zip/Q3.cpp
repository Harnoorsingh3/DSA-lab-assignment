#include <iostream>
using namespace std;

#define MAX 100000

int main() {
    int nums[] = {2, 3, 2, 4, 3, 2};
    int n = 6;

    int hash[MAX] = {0};

    for (int i = 0; i < n; i++)
        hash[nums[i]]++;

    for (int i = 0; i < n; i++) {
        if (hash[nums[i]] != -1) {
            cout << nums[i] << " -> " << hash[nums[i]] << " times\n";
            hash[nums[i]] = -1;
        }
    }
}
