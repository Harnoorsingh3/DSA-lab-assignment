#include <iostream>
using namespace std;

#define MAX 100000

struct Node {
    int data;
    Node* left;
    Node* right;
};

bool checkDuplicate(Node* root, int hash[]) {
    if (root == NULL)
        return false;

    if (hash[root->data] == 1)
        return true;

    hash[root->data] = 1;

    return checkDuplicate(root->left, hash) ||
           checkDuplicate(root->right, hash);
}

int main() {
    int hash[MAX] = {0};

    Node* root = new Node{1, NULL, NULL};
    root->left = new Node{2, NULL, NULL};
    root->right = new Node{3, NULL, NULL};
    root->left->left = new Node{4, NULL, NULL};
    root->right->right = new Node{2, NULL, NULL};

    if (checkDuplicate(root, hash))
        cout << "Duplicates Found";
    else
        cout << "No Duplicates";
}
