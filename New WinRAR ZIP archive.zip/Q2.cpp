#include <iostream>
using namespace std;

#define MAX 100000

int main() {
    int A[] = {1, 2, 3, 4};
    int B[] = {3, 4, 5, 6};
    int n = 4, m = 4;

    int hash[MAX] = {0};

    for (int i = 0; i < n; i++)
        hash[A[i]] = 1;

    for (int i = 0; i < m; i++) {
        if (hash[B[i]] == 1)
            cout << B[i] << " ";
    }
}
