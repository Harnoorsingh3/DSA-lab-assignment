#include <iostream>
using namespace std;

#define MAX 100000

bool containsDuplicate(int nums[], int n) {
    int hash[MAX] = {0};

    for (int i = 0; i < n; i++) {
        if (hash[nums[i]] == 1)
            return true;
        hash[nums[i]] = 1;
    }
    return false;
}

int main() {
    int nums[] = {1, 2, 3, 1};
    int n = 4;

    if (containsDuplicate(nums, n))
        cout << "true";
    else
        cout << "false";
}
